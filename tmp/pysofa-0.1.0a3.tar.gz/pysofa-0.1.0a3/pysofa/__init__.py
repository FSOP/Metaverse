# -*- coding: utf-8  -*-

#
# Copyright 2010 Frédéric Grollier
#
# Distributed under the terms of the MIT license.
#

from pysofa_ctypes import *

